//
//  MainViewController.swift
//  LottoManager
//
//  Created by Rahul on 4/1/15.
//  Copyright (c) 2015 Rahul. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

    @IBOutlet var savedgamesLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //obtain saved values from NSUserDefault if they exist
        let savedticket = NSUserDefaults.standardUserDefaults()
        if let readArray: [NSString] = savedticket.objectForKey("storedgame") as? [NSString] {
            //if there are saved games, show them in the label
            //display the name of the game and the time stamp when it was saved
            savedgamesLabel.text = readArray[0] + " " + readArray[4] + " " + readArray[5]
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func newBtnClicked(sender: UIButton) {
        self.performSegueWithIdentifier("ToGameInfo", sender: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
