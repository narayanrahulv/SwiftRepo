//
//  ViewController.swift
//  LottoManager
//
//  Created by Rahul on 4/1/15.
//  Copyright (c) 2015 Rahul. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var ticketNumTextField : UITextField!
    @IBOutlet var gameNameTextField: UITextField!
    @IBOutlet var prizeTextField: UITextField!
    @IBOutlet var gameDate: UIDatePicker!
    @IBOutlet var saveGameBtn: UIButton!
    @IBOutlet var stateLabel: UILabel!
    
    //variables to hold user enry which will be saved
    var ticketNum: String = ""
    var gameName: String = ""
    var prizeMoney: String = ""
    var drawDate: String = ""
    var stateselected: String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //obtain saved values from NSUserDefault if they exist
        let savedticket = NSUserDefaults.standardUserDefaults()
        /*if let savedTicketNum = savedticket.stringForKey("ticketNum") {
                ticketNumTextField.text = savedTicketNum
        }*/
        if let readArray: [NSString] = savedticket.objectForKey("storedgame") as? [NSString] {
            println(readArray)
            ticketNumTextField.text = readArray[0]
            gameNameTextField.text = readArray[1]
            prizeTextField.text = readArray[2]
            /*let dateformatter: NSDateFormatter = NSDateFormatter()
            dateformatter.dateFormat = "MM-dd-yyyy HH:mm"
            if let retrieveddate = readArray[3] as NSString? {
                if (retrieveddate != "") {
                    gameDate.date = dateformatter.dateFromString(retrieveddate)!
                }
            }*/
            stateLabel.text = readArray[4]
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //button events
    @IBAction func saveGameTapped(sender: AnyObject) {
        //get form values
        ticketNum = ticketNumTextField.text
        gameName = gameNameTextField.text
        prizeMoney = prizeTextField.text
        stateselected = stateLabel.text!
        
        //perform validation
        if(ticketNum == "") {
            let alertController = UIAlertController(title: "empty ticket number", message: "enter a ticket number", preferredStyle: .Alert)
            let alertAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Destructive, handler: {(alert : UIAlertAction!) in
                alertController.dismissViewControllerAnimated(true, completion: nil)
            })
            alertController.addAction(alertAction)
            presentViewController(alertController, animated: true, completion: nil)
        }
        else if(gameName == "") {
            let alertController = UIAlertController(title: "empty game", message: "enter a game", preferredStyle: .Alert)
            let alertAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Destructive, handler: {(alert : UIAlertAction!) in
                alertController.dismissViewControllerAnimated(true, completion: nil)
            })
            alertController.addAction(alertAction)
            presentViewController(alertController, animated: true, completion: nil)
        }
        else if(prizeMoney == "") {
            let alertController = UIAlertController(title: "no prize money", message: "enter a prize amount", preferredStyle: .Alert)
            let alertAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Destructive, handler: {(alert : UIAlertAction!) in
                alertController.dismissViewControllerAnimated(true, completion: nil)
            })
            alertController.addAction(alertAction)
            presentViewController(alertController, animated: true, completion: nil)
        }
        else {
            //store into NSUserDefault
            let storedgamedef = NSUserDefaults.standardUserDefaults()
            var gamekey = "storedgame"
            var curdatetime: NSDate = NSDate()
            var curdateformatter: NSDateFormatter = NSDateFormatter()
            curdateformatter.dateFormat = "MM-dd-yyyy HH:mm"
            var curdateformat: String = curdateformatter.stringFromDate(curdatetime)
        
            var storedgameArr: [NSString] = [NSString]()
            storedgameArr.append(ticketNum)
            storedgameArr.append(gameName)
            storedgameArr.append(prizeMoney)
            storedgameArr.append(drawDate)
            storedgameArr.append(stateselected)
            storedgameArr.append(curdateformat)
        
            storedgamedef.setObject(storedgameArr, forKey: gamekey)
            /*
            let defaultticket = NSUserDefaults.standardUserDefaults()
            defaultticket.setObject(ticketNum, forKey: "ticketNum")
            defaultticket.setObject(gameName, forKey: "gameName")
            defaultticket.setObject(prizeMoney, forKey: "prizeMoney")
            defaultticket.setObject(drawDate, forKey: "drawDate")*/
            println(storedgameArr[0])
            println(storedgameArr[1])
            println(storedgameArr[5])
            
            let alertController = UIAlertController(title: "Game Saved", message: "ticket" + storedgameArr[0] + "is saved on" + storedgameArr[5], preferredStyle: .Alert)

            let alertAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Destructive, handler: {(alert : UIAlertAction!) in
                alertController.dismissViewControllerAnimated(true, completion: nil)
            })
            alertController.addAction(alertAction)
            presentViewController(alertController, animated: true, completion: nil)
        }
    }
    
    @IBAction func setGameState(sender: UIButton) {
        self.performSegueWithIdentifier("ToStatePicker", sender: self)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let statevc = segue.destinationViewController as StateViewController
        statevc.originvc = self
    }
    
    //tap events
    @IBAction func viewTapped(sender: AnyObject) {
    }
    
    //date picker events
    @IBAction func datePickerClicked(datePicker: UIDatePicker) {
        var dateFormatter = NSDateFormatter()
        dateFormatter.dateStyle = NSDateFormatterStyle.FullStyle
        var dateStr = dateFormatter.stringFromDate(datePicker.date)
        drawDate = dateStr
    }
    
    //NSUserDefault: could use key value pair to store and reference across views
    //may not need a model for this
}

