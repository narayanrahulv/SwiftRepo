//
//  LottoManagerModel.swift
//  LottoManager
//
//  Created by Rahul on 4/1/15.
//  Copyright (c) 2015 Rahul. All rights reserved.
//

import Foundation

class LottoManagerModel {
    
}