//
//  GameScene.swift
//  TennisTrainer
//
//  Created by Rahul on 4/29/15.
//  Copyright (c) 2015 Rahul. All rights reserved.
//

import SpriteKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    //create player icon
    let player = SKSpriteNode(imageNamed: "Tennis_Racket_icon.png")
    
    //create net icon
    let net = SKSpriteNode(imageNamed: "tennis_net.jpeg")
    
    //create needed counters
    var goodshots = 0
    var missedshots = 0
    var winscore = 12
    var losescore = -12
    
    //label to show player realtime score
    let scoreLabel = SKLabelNode(fontNamed: "Chalkduster")
    
    struct PhysicsCategory {
        static let None : UInt32 = 0
        static let All  : UInt32 = UInt32.max
        static let Racket  : UInt32 = 0b10
        static let Ball : UInt32 = 0b1
    }
    
    override func didMoveToView(view: SKView) {
        /* Setup your scene here */
        let myLabel = SKLabelNode(fontNamed:"Chalkduster")
        myLabel.text = "Tennis Trainer:";
        myLabel.fontSize = 50;
        myLabel.position = CGPoint(x:CGRectGetMidX(self.frame), y:CGRectGetMidY(self.frame));
        
        self.addChild(myLabel)
        
        backgroundColor = SKColor.greenColor()
        
        //set up the net
        if let node = self.childNodeWithName("my net"){
            //nothing done
        }
        else {
            //position net icon
            net.position = CGPoint(x: size.width * 0.9, y: size.height * 0.4)
            
            net.name = "my net"
            self.addChild(net)
        }
        
        //initializing physics for racket
        physicsWorld.gravity = CGVectorMake(0,0)
        physicsWorld.contactDelegate = self
        player.physicsBody = SKPhysicsBody(circleOfRadius: player.size.width/2)
        player.physicsBody?.dynamic = true
        player.physicsBody?.categoryBitMask = PhysicsCategory.Racket
        player.physicsBody?.contactTestBitMask = PhysicsCategory.Ball
        player.physicsBody?.collisionBitMask = PhysicsCategory.None
        
        //start firing tennis balls at player
        runAction(SKAction.repeatActionForever(
            SKAction.sequence([SKAction.runBlock(playBall), SKAction.waitForDuration(2.0)])))
        
        //no need to show the intro label once game starts
        myLabel.removeFromParent()
        
        //show new label that tells player their score
        scoreLabel.text = "Current Score:" + String(goodshots)
        scoreLabel.fontSize = 30
        scoreLabel.position = CGPoint(x:CGRectGetMidX(self.frame), y:CGRectGetMidY(self.frame));
        self.addChild(scoreLabel)
    }
    
    override func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        /* Called when a touch begins */
        let touch = touches.anyObject() as UITouch
        let location = touch.locationInNode(self)
            if let node = self.childNodeWithName("my racket")
            {
                //move to clicked location
                let pos = CGPoint(x: size.width * 0.1, y: location.y)
                
                let disty = abs(self.position.y - location.y)
                let dur = 1.0/disty * 100
                
                let actionMove = SKAction.moveTo(pos, duration: NSTimeInterval (dur))
                
                //let actionMoveDone = SKAction.removeFromParent()
                self.player.runAction(SKAction.sequence([actionMove]))
            } else {
                //position player icon
                player.position = CGPoint(x: size.width * 0.1, y: size.height * 0.5)
                
                player.name = "my racket"
                self.addChild(player)
            }
    }
    
    //determining which object would be considered first/second object during a collision
    func didBeginContact(contact: SKPhysicsContact) {
        var firstBody: SKPhysicsBody
        var secondBody: SKPhysicsBody
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            firstBody = contact.bodyA
            secondBody = contact.bodyB
        } else {
            firstBody = contact.bodyB
            secondBody = contact.bodyA
        }
        
        if((firstBody.categoryBitMask & PhysicsCategory.Ball != 0) && (secondBody.categoryBitMask & PhysicsCategory.Racket != 0)) {
            ballDidCollideWithRacket(firstBody.node as SKSpriteNode, racket: secondBody.node as SKSpriteNode)
        }
    }
    
    //if user successfully hits the ball with their racket
    func ballDidCollideWithRacket(ball:SKSpriteNode, racket:SKSpriteNode) {
        //upon collision remove old ball that came from right
        ball.removeFromParent()
        
        //replace with new ball at point of collision and move that ball towards the right
        //where the original ball came from
        let newball = SKSpriteNode(imageNamed: "tennis_ball.png")
        
        newball.position = racket.position
        
        let newballY = randomPosition(min: size.height/2, max:size.height)
        
        let endpos = CGPoint(x: self.size.width + ball.size.width/2, y: newballY)
        
        addChild(newball)
        
        let ballDuration = randomPosition(min: CGFloat(2.0), max: CGFloat(4.0))
        
        let actionMove = SKAction.moveTo(endpos, duration: NSTimeInterval(ballDuration))
        let actionMoveDone = SKAction.removeFromParent()
        newball.runAction(SKAction.sequence([actionMove, actionMoveDone]))
        
        //player made a shot: update their score and display it
        goodshots++
        
        //show player their score
        scoreLabel.text = String(goodshots)
        scoreLabel.fontSize = 30
        //scoreLabel.position = CGPoint(x:CGRectGetMidX(self.frame), y:CGRectGetMidY(self.frame));
        
        if(goodshots == winscore) {
            let reveal = SKTransition.flipHorizontalWithDuration(0.5)
            let gameOverScene = GameOverScene(size: self.size, won: true)
            self.view?.presentScene(gameOverScene, transition: reveal)
        }
    }
   
    override func update(currentTime: CFTimeInterval) {

    }
    
    func myRandom() -> CGFloat {
        return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }
    
    func randomPosition(#min: CGFloat, max: CGFloat) -> CGFloat {
        return myRandom() * (max - min) + min
    }
    
    //function that generates tennis balls and shoots them out from random location on the
    //right of the game screen
    func playBall() {
        let ball = SKSpriteNode(imageNamed: "tennis_ball.png")
        
        //initializing physics for ball
        ball.physicsBody = SKPhysicsBody(rectangleOfSize: ball.size)
        ball.physicsBody?.dynamic = true
        ball.physicsBody?.categoryBitMask = PhysicsCategory.Ball
        ball.physicsBody?.contactTestBitMask = PhysicsCategory.Racket
        ball.physicsBody?.collisionBitMask = PhysicsCategory.None
        
        //place where the tennis balls will come from
        let actualY = randomPosition(min: size.height/2, max: size.height)
        
        //should come from off the screen on the right
        ball.position = CGPoint(x: size.width + ball.size.width/2, y: actualY)
        
        //add ball to the scene
        addChild(ball)
        
        //speed
        let ballDuration = randomPosition(min: CGFloat(2.0), max: CGFloat(4.0))
        
        //creating actions
        let actionMove = SKAction.moveTo(CGPoint(x: ball.size.width/2, y: actualY), duration: NSTimeInterval(ballDuration))
        let actionMoveDone = SKAction.removeFromParent()
        let loseAction = SKAction.runBlock() {
            let reveal = SKTransition.flipHorizontalWithDuration(0.5)
            let gameOverScene = GameOverScene(size: self.size, won: false)
            self.view?.presentScene(gameOverScene, transition: reveal)
        }
        ball.runAction(SKAction.sequence([actionMove, loseAction, actionMoveDone]))
    }
}
